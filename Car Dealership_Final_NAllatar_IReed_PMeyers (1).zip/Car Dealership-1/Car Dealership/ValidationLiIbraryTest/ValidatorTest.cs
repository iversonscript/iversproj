﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Windows.Forms;
using ValidationLibrary;

namespace ValidationLiIbraryTest
{
    [TestClass]
    public class ValidatorTest
    {
        [TestMethod]
        public void IsDecimal_ValidValue()
        {
            TextBox txtBox = new TextBox();
            txtBox.Text = "3.14";

            bool expected = true; // arrange
            var result = Validator.IsDecimal(txtBox); // act
            Assert.AreEqual(expected, result); // assert
        }

        [TestMethod]
        public void IsPresent_ValidValue()
        {
            TextBox txtBox = new TextBox();
            txtBox.Text = "";

            bool expected = false; // arrange
            var result = Validator.IsPresent(txtBox); // act
            Assert.AreEqual(expected, result); // assert
         

        
        }
    }
}

