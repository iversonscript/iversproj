﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Dealership
{
    public static class Validator
    {
        //Static field.
        private static string lineEnd = "\n";

        //Static field read and write property.
        public static string LineEnd
        {
            get { return lineEnd; }
            set { lineEnd = value; }
        }

        public static IFormatProvider Nothing { get; private set; }

        //Static method to check if value of control with 'name' exists.
        public static string IsPresent(string value, string name)
        {
            string msg = "";
            if (value == "")
            {
                msg += name + " is a required field." + LineEnd;
            }
            return msg;
        }

        public static string IsDecimal(string value, string name)
        {
            string msg = "";
            if (!Decimal.TryParse(value, out _))
            {
                msg += name + " must be a valid decimal value." + LineEnd;
            }
            return msg;
        }

        public static string IsString(string value, string name)
        {
            string msg = "";
            if (!value.All(c=> Char.IsLetter(c)))
            {
                msg += name + " must be a valid string value." + LineEnd;
            }
            return msg;
        }

        public static string IsDate(string value, string name)
        {
            string msg = "";
            if (!DateTime.TryParseExact(value, "MM/dd/yyyy", Nothing, System.Globalization.DateTimeStyles.None, out _))
            {
                msg += name + " must be a valid date value, In the formate of mm/dd/yyyy" + LineEnd;
            }
            return msg;
        }
    }
}
