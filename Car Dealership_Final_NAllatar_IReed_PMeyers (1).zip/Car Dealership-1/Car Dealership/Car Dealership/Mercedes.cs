﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Dealership
{
    class Mercedes:Car
    {
        public static string Tag { get; } = "Fuel";
        public string Fuel { set; get; }

        public Mercedes(string make, string model, string color, string fuel, DateTime created, decimal price)
         : base(make, model, color, created, price)
        {
            this.Fuel =fuel;
        }

        public Mercedes() { }

        public override string GetDisplayText(string sep) =>
            this.Make + sep + this.Model + sep + this.Color + sep + "Fuel: " + this.Fuel + sep +
            this.Age+"Years" + sep + this.Price.ToString("c");

        public override string DisplayTextOnFile(string sep) =>
          this.Make + sep + this.Model + sep + this.Color + sep + "Fuel: " + this.Fuel + sep +
          this.CreatedAt.ToString("MM/dd/yyyy") + sep + this.Price.ToString("c");

        public override string ToString(string sep, Enum filterCat) =>
          base.ToString(sep, filterCat) + sep+ ((Fuel == null) ? "" : Fuel);

      //  public override int CompareTo(ICar other, string filter) => base.CompareTo(other, filter)+ 
       
    }
}
