﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Car_Dealership
{
    public class CarList<T> where T: ICar
    {
        List<T> cars;

        public CarList()
        {
            cars = new List<T>();
        }
        public void Sort()
        {
            cars.Sort((car1, car2) =>
             {
                 var firstCompare = car1.Age.CompareTo(car2.Age);
                 return firstCompare != 0 ? firstCompare : car1.Age.CompareTo(car2.Age);
             });
        }
        public int Count()
        {
            return cars.Count();
        }
        public void Remove(T car)
        {
            cars.Remove(car);
        }

        public void Add(T car) {
            cars.Add(car);
        }
        public void Add(T car, int index)
        {
            cars.Insert( index, car);
        }
        // Indexer uses int as an index 
        public ICar this[int i]
        {
            get
            {              
                    return cars[i];
            }

            set { cars[i] = (T)value; }
        }

        public IEnumerator<T> GetEnumerator()
        {
            foreach (T item in cars)
            {
                yield return item;
            }
        }

        public List<T> GetList()
        {
            return cars;
        }

        //Additional method: Fill
        public void Fill() => cars = CarDB<T>.GetCars();
       
        //Additional method: Save
        public void Save() => CarDB<T>.SaveCars(cars);

    }
}
