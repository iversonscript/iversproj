﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Dealership
{
    class Honda : Car
    {
        public static string Tag { get; } = "Tire Pressure";
        public string Tire_Pressure { set; get; }

        public Honda(string make, string model, string color, string tire_pressure, DateTime created, decimal price)
         : base(make, model, color, created, price)
        {
            this.Tire_Pressure = tire_pressure;
        }

        public Honda() { }

        public override string GetDisplayText(string sep) =>
            this.Make + sep + this.Model + sep + this.Color + sep + "Tire Pressure: " + this.Tire_Pressure+"psi" +
            sep + this.Age+"Years" + sep + this.Price.ToString("c");

        public override string DisplayTextOnFile(string sep) =>
          this.Make + sep + this.Model + sep + this.Color + sep + "Tire Pressure: " + this.Tire_Pressure + sep +
          this.CreatedAt.ToString("MM/dd/yyyy") + sep + this.Price.ToString("c");

        public override string ToString(string sep, Enum filterCat) =>
           base.ToString(sep, filterCat) + sep+ ((Tire_Pressure.ToString() == null) ? "" : Tire_Pressure.ToString());
    }
}
