﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Car_Dealership.frmCarDealership;

namespace Car_Dealership
{
    public abstract class Car : ICar
    {
        public string Make { set; get; }
        public string Model { set; get; }
        public string Color { set; get; }
        public decimal Price { set; get; }
        public DateTime CreatedAt { get; set; }
        public DateTime BirthDate { get; set; }

        public int Age
        {
            get
            {
                TimeSpan diff = DateTime.Today - CreatedAt;
                return (int)(diff.Days / 365.2425);
            }
            set
            {
                CreatedAt = DateTime.Today.AddYears(-value);
            }
        }
        public Car() { }

        public Car(string make, string model, string color, DateTime created, decimal price)
        {
            this.Make = make;
            this.Model = model;
            this.Color = color;
            this.CreatedAt = created;
            this.Price = price;
        }

        public virtual string GetDisplayText(string sep) =>
                           Make + sep + Model + sep + Color + sep +
                           Age.ToString() + " Years" + sep + Price.ToString("c");

        public virtual string DisplayTextOnFile(string sep) =>
                           Make + sep + Model + sep + Color + sep +
                           CreatedAt.ToString("MM/dd/yyyy") + sep + Price.ToString("c");

        public virtual string ToString(string sep, Enum filterCat)
        {
            string msg = "";
            string make = Make ?? "";
            string color = (Color == null) ? "" : Color;
            string age = (Age.ToString() == null) ? "" : Age.ToString() + " Years";
            string price = (Price.ToString() == null) ? "" : Price.ToString("c");

            if (filterCat.Equals(FilterCat.Make))
            {
                msg += Model + sep;
                msg += color + sep + age + sep + price;
            }
            else if (filterCat.Equals(FilterCat.Color))
            {
                msg += Model + sep;
                msg += make + sep + age + sep + price;
            }
            else if (filterCat.Equals(FilterCat.Age))
            {
                msg += Model + sep;
                msg += make + sep + price;
            }
            else if (filterCat.Equals(FilterCat.Price))
            {
                msg += Model + sep;
                msg += make + sep + age;
            }

            return msg;
        }

        public virtual int CompareTo(ICar other)
        {
            return this.CreatedAt.CompareTo(other.CreatedAt);
        }

        public virtual int CompareTo(ICar other, string filter)
        {
            if (filter == "Color")
            {
                return this.Color.CompareTo(other.Color);
            }
            else if (filter == "Make")
            {
                return this.Make.CompareTo(other.Make);
            }
            else if (filter == "Age")
            {
                return this.Make.CompareTo(other.Age);
            }
            else if (filter == "Price")
            {
                return this.Make.CompareTo(other.Price);
            }
            else
                return this.CreatedAt.CompareTo(other.CreatedAt);
        }

    }
}
