﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Dealership
{
    public struct FilterBy
    {
       /* private SortedList<string, Car> make;
        private SortedList<string, Car> model;
        private SortedList<string, Car> color;
        private SortedList<int, Car> age;
        private SortedList<decimal, Car> price;
     
        public SortedList<string, Car> Make { get => make; set => make = value; }
        public SortedList<string, Car> Model { get => model; set => model = value; }
        public SortedList<string, Car> Color { get => color; set => color = value; }
        public SortedList<int, Car> Age { get => age; set => age = value; }
        public SortedList<decimal, Car> Price { get => price; set => price = value; }*/
        
      /*  public string GetColor()
        {
            string msg="";
            List<Car> carListingsData = new List<Car>();

            // Display the cars grouped by color           
                // Get a distinct list of colors from the car data
                var distinctColors = carListingsData.Select(c => c.Color).Distinct().OrderBy(c => c);

                // Group the cars by color
                var groupedByColor = carListingsData.OrderBy(c => c.CreatedAt)
                                                    .GroupBy(c => c.Color);

                // Display the cars under each color
                foreach (var color in distinctColors)
                {
                    msg+= $"- {color}";

                    foreach (var car in groupedByColor.FirstOrDefault(g => g.Key == color))
                    {
                        msg+= $"  - {car.Make} {car.Model}";
                    }
                }

            return msg;
            
        }*/

    }
}
