﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Dealership
{
    public class CarDB<T> where T : ICar
    {

        const string dir = @"C:\Users\olyme\Desktop\SPSCC\Spring_2023\CIS_166\Car Dealership-1\Car Dealership";
        const string path = dir + "car.txt";

        public static List<T> GetCars()
        {
            if (!Directory.Exists(dir))
                Directory.CreateDirectory(dir);

            StreamReader textIn = new StreamReader(new FileStream(path, FileMode.OpenOrCreate, FileAccess.Read));
            List<T> cars = new List<T>();

            while (textIn.Peek() != -1)
            {
                string row = textIn.ReadLine();
                string[] columns = row.Split('|');
                ICar car = null;
                var propertyType = columns[3].Split(':')[0];
                if (propertyType == BMW.Tag)
                {
                    car = new BMW(columns[0],
                                      columns[1],
                                      columns[2],
                                      columns[3].Split(':')[1].Trim(),
                                      Convert.ToDateTime(columns[4]), Convert.ToDecimal(columns[5].Replace("$", "")));
                }

                else if (propertyType == Toyota.Tag)
                {
                    car = new Toyota(columns[0],
                                      columns[1],
                                      columns[2],
                                      columns[3].Split(':')[1].Trim(),
                                      Convert.ToDateTime(columns[4]), Convert.ToDecimal(columns[5].Replace("$", "")));
                }

                else if (propertyType == Honda.Tag)
                {
                    car = new Honda(columns[0],
                                      columns[1],
                                      columns[2],
                                      columns[3].Split(':')[1].Trim(),
                                      Convert.ToDateTime(columns[4]), Convert.ToDecimal(columns[5].Replace("$", "")));
                }
                else if (propertyType == Mercedes.Tag)
                {
                    car = new Mercedes(columns[0],
                                      columns[1],
                                      columns[2],
                                      columns[3].Split(':')[1].Trim(),
                                      Convert.ToDateTime(columns[4]), Convert.ToDecimal(columns[5].Replace("$", "")));              
                }

                cars.Add((T)car);
            }
            textIn.Close();

            return cars;
        }

        public static void SaveCars(List<T> cars)
        {
            StreamWriter textOut = new StreamWriter(new FileStream(path, FileMode.Create, FileAccess.Write));
          
            foreach (T car in cars)
            {
                textOut.WriteLine(car.DisplayTextOnFile("|"));          
            }
            textOut.Close();
        }
    }
}
