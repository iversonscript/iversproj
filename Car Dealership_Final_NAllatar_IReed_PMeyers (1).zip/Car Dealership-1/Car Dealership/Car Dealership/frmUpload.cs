﻿using System;
using System.Windows.Forms;
using ValidationLibrary;

namespace Car_Dealership
{
    public partial class frmUpload : Form
    {
       private ICar car = null;

        public enum ChooseMake
        {
            BMW = 1,
            Honda = 2,
            Toyota = 3,
            Mercedes = 4
        }

        public frmUpload()
        {
            InitializeComponent();
            Load += new EventHandler(frmCarDealership_Load);
        }

        private void frmCarDealership_Load(object sender, EventArgs e)
        {
            cboChooseMake.DataSource = new[] { "Select a Make:", "BMW", "Honda", "Toyota", "Mercedes" };
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void cboChooseMake_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cboChooseMake.SelectedIndex == (int)ChooseMake.Honda)
            {
                lblUniProperty.Text = "Tire-Pressure (int)";
            }
            else if(cboChooseMake.SelectedIndex ==(int)ChooseMake.Toyota)
            {
                lblUniProperty.Text = "Mileage";
            }
            else if (cboChooseMake.SelectedIndex == (int)ChooseMake.Mercedes)
            {
                lblUniProperty.Text = "Fuel";
            }
        }

        private bool IsValidData()
        {
            bool success = true;
            string errorMessage = "";

            errorMessage += Validator.IsPresent(txtModel);
            errorMessage += Validator.IsPresent(txtColor);
            errorMessage += Validator.IsPresent(txtUniProperty);
            errorMessage += Validator.IsPresent(txtPrice);
            errorMessage += Validator.IsPresent(txtCreationDate);

            errorMessage += Validator.IsDecimal(txtPrice);

           // errorMessage += Validator.IsDate(txtCreationDate);

            //errorMessage += Validator.IsString(txtColor.Text, txtColor.Tag.ToString());

            if (errorMessage != "")
            {
                success = false;
                MessageBox.Show(errorMessage, "Entry Error");
            }
            return success;
        }

        public ICar GetNewCar()
        {
            this.ShowDialog();
            return car;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
           
            if (IsValidData())
            {
               // car = new ICar();
                if (cboChooseMake.SelectedIndex == (int)ChooseMake.BMW)
                {
                    car  = new BMW(cboChooseMake.SelectedItem.ToString(), txtModel.Text, char.ToUpper(txtColor.Text[0])+ txtColor.Text.Substring(1),
                        txtUniProperty.Text, DateTime.Parse(txtCreationDate.Text), Convert.ToInt32(txtPrice.Text));
                }
                else if (cboChooseMake.SelectedIndex == (int)ChooseMake.Toyota)
                {
                    car = new Toyota(cboChooseMake.SelectedItem.ToString(), txtModel.Text, char.ToUpper(txtColor.Text[0]) + txtColor.Text.Substring(1),
                        txtUniProperty.Text, DateTime.Parse(txtCreationDate.Text), Convert.ToInt32(txtPrice.Text));
                }
                else if (cboChooseMake.SelectedIndex == (int)ChooseMake.Honda)
                {
                    car = new Honda(cboChooseMake.SelectedItem.ToString(), txtModel.Text, char.ToUpper(txtColor.Text[0]) + txtColor.Text.Substring(1),
                        txtUniProperty.Text, DateTime.Parse(txtCreationDate.Text), Convert.ToInt32(txtPrice.Text));                 
                }
                else if (cboChooseMake.SelectedIndex == (int)ChooseMake.Mercedes)
                {
                    car = new Mercedes(cboChooseMake.SelectedItem.ToString(), txtModel.Text, char.ToUpper(txtColor.Text[0]) + txtColor.Text.Substring(1),
                        txtUniProperty.Text, DateTime.Parse(txtCreationDate.Text), Convert.ToInt32(txtPrice.Text));
                }
                else                
                    car = null;                
                this.Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmUpload_Load(object sender, EventArgs e)
        {

        }
    }
}
