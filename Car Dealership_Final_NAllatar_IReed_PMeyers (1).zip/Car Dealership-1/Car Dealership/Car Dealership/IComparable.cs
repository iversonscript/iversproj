﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Dealership
{
    public interface IComparable
    {
        int CompareTo(ICar other, string filter);
    }
}
