﻿
namespace Car_Dealership
{
    partial class frmUpload
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cboChooseMake = new System.Windows.Forms.ComboBox();
            this.lblChooseMake = new System.Windows.Forms.Label();
            this.lblModel = new System.Windows.Forms.Label();
            this.lblColor = new System.Windows.Forms.Label();
            this.lblCreationDate = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.txtModel = new System.Windows.Forms.TextBox();
            this.txtColor = new System.Windows.Forms.TextBox();
            this.txtCreationDate = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.lblUniProperty = new System.Windows.Forms.Label();
            this.txtUniProperty = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cboChooseMake
            // 
            this.cboChooseMake.FormattingEnabled = true;
            this.cboChooseMake.Location = new System.Drawing.Point(132, 16);
            this.cboChooseMake.Name = "cboChooseMake";
            this.cboChooseMake.Size = new System.Drawing.Size(121, 21);
            this.cboChooseMake.TabIndex = 0;
            this.cboChooseMake.Tag = "Car_Make";
            this.cboChooseMake.SelectedIndexChanged += new System.EventHandler(this.cboChooseMake_SelectedIndexChanged);
            // 
            // lblChooseMake
            // 
            this.lblChooseMake.AutoSize = true;
            this.lblChooseMake.Location = new System.Drawing.Point(36, 16);
            this.lblChooseMake.Name = "lblChooseMake";
            this.lblChooseMake.Size = new System.Drawing.Size(76, 13);
            this.lblChooseMake.TabIndex = 1;
            this.lblChooseMake.Text = "Choose Make:";
            // 
            // lblModel
            // 
            this.lblModel.AutoSize = true;
            this.lblModel.Location = new System.Drawing.Point(36, 50);
            this.lblModel.Name = "lblModel";
            this.lblModel.Size = new System.Drawing.Size(36, 13);
            this.lblModel.TabIndex = 2;
            this.lblModel.Text = "Model";
            // 
            // lblColor
            // 
            this.lblColor.AutoSize = true;
            this.lblColor.Location = new System.Drawing.Point(36, 90);
            this.lblColor.Name = "lblColor";
            this.lblColor.Size = new System.Drawing.Size(31, 13);
            this.lblColor.TabIndex = 3;
            this.lblColor.Text = "Color";
            this.lblColor.Click += new System.EventHandler(this.label3_Click);
            // 
            // lblCreationDate
            // 
            this.lblCreationDate.AutoSize = true;
            this.lblCreationDate.Location = new System.Drawing.Point(36, 127);
            this.lblCreationDate.Name = "lblCreationDate";
            this.lblCreationDate.Size = new System.Drawing.Size(72, 13);
            this.lblCreationDate.TabIndex = 4;
            this.lblCreationDate.Text = "Creation Data";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(36, 164);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(31, 13);
            this.lblPrice.TabIndex = 5;
            this.lblPrice.Text = "Price";
            // 
            // txtModel
            // 
            this.txtModel.Location = new System.Drawing.Point(132, 50);
            this.txtModel.Name = "txtModel";
            this.txtModel.Size = new System.Drawing.Size(100, 20);
            this.txtModel.TabIndex = 6;
            this.txtModel.Tag = "Car_Model";
            // 
            // txtColor
            // 
            this.txtColor.Location = new System.Drawing.Point(132, 90);
            this.txtColor.Name = "txtColor";
            this.txtColor.Size = new System.Drawing.Size(100, 20);
            this.txtColor.TabIndex = 7;
            this.txtColor.Tag = "Car_Color";
            // 
            // txtCreationDate
            // 
            this.txtCreationDate.Location = new System.Drawing.Point(132, 127);
            this.txtCreationDate.Name = "txtCreationDate";
            this.txtCreationDate.Size = new System.Drawing.Size(100, 20);
            this.txtCreationDate.TabIndex = 8;
            this.txtCreationDate.Tag = "Car_Creation Date";
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(132, 164);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(100, 20);
            this.txtPrice.TabIndex = 9;
            this.txtPrice.Tag = "Car_Price";
            // 
            // lblUniProperty
            // 
            this.lblUniProperty.AutoSize = true;
            this.lblUniProperty.Location = new System.Drawing.Point(36, 200);
            this.lblUniProperty.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUniProperty.Name = "lblUniProperty";
            this.lblUniProperty.Size = new System.Drawing.Size(40, 13);
            this.lblUniProperty.TabIndex = 10;
            this.lblUniProperty.Text = "Engine";
            // 
            // txtUniProperty
            // 
            this.txtUniProperty.Location = new System.Drawing.Point(132, 200);
            this.txtUniProperty.Margin = new System.Windows.Forms.Padding(2);
            this.txtUniProperty.Name = "txtUniProperty";
            this.txtUniProperty.Size = new System.Drawing.Size(100, 20);
            this.txtUniProperty.TabIndex = 11;
            this.txtUniProperty.Tag = "Car_ Unique Property";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(58, 245);
            this.btnSave.Margin = new System.Windows.Forms.Padding(2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(63, 23);
            this.btnSave.TabIndex = 12;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(125, 245);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(2);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(70, 23);
            this.btnCancel.TabIndex = 13;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // frmUpload
            // 
            this.AcceptButton = this.btnSave;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(260, 285);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtUniProperty);
            this.Controls.Add(this.lblUniProperty);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.txtCreationDate);
            this.Controls.Add(this.txtColor);
            this.Controls.Add(this.txtModel);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblCreationDate);
            this.Controls.Add(this.lblColor);
            this.Controls.Add(this.lblModel);
            this.Controls.Add(this.lblChooseMake);
            this.Controls.Add(this.cboChooseMake);
            this.Name = "frmUpload";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Upload Form";
            this.Load += new System.EventHandler(this.frmUpload_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cboChooseMake;
        private System.Windows.Forms.Label lblChooseMake;
        private System.Windows.Forms.Label lblModel;
        private System.Windows.Forms.Label lblColor;
        private System.Windows.Forms.Label lblCreationDate;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.TextBox txtModel;
        private System.Windows.Forms.TextBox txtColor;
        private System.Windows.Forms.TextBox txtCreationDate;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Label lblUniProperty;
        private System.Windows.Forms.TextBox txtUniProperty;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
    }
}