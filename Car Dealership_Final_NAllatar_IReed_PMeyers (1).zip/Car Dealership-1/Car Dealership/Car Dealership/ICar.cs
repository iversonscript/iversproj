﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Dealership
{
    public interface ICar :  IComparable<ICar>, IDisplayable
    {
        string Make { set; get; }
        string Model { set; get; }
        string Color { set; get; }
        int Age { set; get; }
        decimal Price { set; get; }
        DateTime CreatedAt { get; set; }
        DateTime BirthDate { get; set; }
    }
}
