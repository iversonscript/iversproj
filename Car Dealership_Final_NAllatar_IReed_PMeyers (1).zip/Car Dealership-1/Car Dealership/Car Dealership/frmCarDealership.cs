﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;


namespace Car_Dealership    
{
    public partial class frmCarDealership : Form
    {
        public frmCarDealership()
        {
            InitializeComponent();
            Load += new EventHandler(frmCarDealership_Load);
        }

        public enum FilterCat
        {
            Make = 1,
            Color = 2,
            Age = 3,
            Price = 4
        }

        private CarList<ICar> cars = new CarList<ICar>();

        private void frmCarDealership_Load(object sender, EventArgs e)
        {
            cars.Fill();
            FillCarListBox();
            cboFilter.DataSource = new[] { "Select a Filter by:", "Make", "Color", "Age", "Price" };
        }

        private void FillCarListBox()
        {
            lstCars.Items.Clear();            
            foreach (ICar c in cars)
            {
                cars.Sort();
                lstCars.Items.Add(c.GetDisplayText(" || "));
            }
        }
        private void FillCarListBox_byColor(string color)
        {
            lstCars.Items.Clear();
            foreach (Car c in cars)
            {
                if (c.Color == color)
                {
                    lstCars.Items.Add(c.ToString(" // ",FilterCat.Color));
                }
            }
        }
        private void FillCarListBox_byMake(string make)
        {
            lstCars.Items.Clear();
            foreach (Car c in cars)
            {
                if (c.Make == make)
                {
                    lstCars.Items.Add(c.ToString(" // ",FilterCat.Make));
                }
            }
        }
        private void FillCarListBox_byAge(int min, int max)
        {
            lstCars.Items.Clear();
            foreach (Car c in cars)
            {
                if (c.Age>=min && c.Age<=max)
                {
                    lstCars.Items.Add(c.ToString(" // ", FilterCat.Age));
                }
            }
        }
        private void FillCarListBox_byPrice(int min, int max)
        {
            lstCars.Items.Clear();
            foreach (Car c in cars)
            {
                if (c.Price >= min && c.Price <= max)
                {
                    lstCars.Items.Add(c.ToString(" // ", FilterCat.Price));
                }
            }
        }

        private void btnViewAll_Click(object sender, EventArgs e)
        {
            FillCarListBox();
        }


        private void cboFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboFilter.SelectedIndex == (int)FilterCat.Make)
            {
                // update sub cat combo
                lstCars.Items.Clear();
                HashSet<string> makes = new HashSet<string>();
                var sortedMakes = from m in makes
                                  orderby m
                                  select m;
                foreach (Car c in cars)
                {
                    makes.Add(c.Make);
                }
                lstSubCat.Items.Clear();
                foreach (var m in sortedMakes)
                {
                    lstSubCat.Items.Add(m);
                }
            }

            else if (cboFilter.SelectedIndex == (int)FilterCat.Color)
            {
                HashSet<string> colors = new HashSet<string>();
                var sortedColors = from m in colors
                                  orderby m
                                  select m;
                foreach (Car c in cars)
                {
                    colors.Add(c.Color);
                }
                lstSubCat.Items.Clear();
                foreach (var c in sortedColors)
                {
                    lstSubCat.Items.Add(c);
                }

            }
            else if (cboFilter.SelectedIndex == (int)FilterCat.Age)
            {
                 lstSubCat.Items.Clear();
                lstSubCat.Items.Add("3-5 Years");
                lstSubCat.Items.Add("5-7 Years");
                lstSubCat.Items.Add("more than 10 Years");

            }
            else if (cboFilter.SelectedIndex == (int)FilterCat.Price)
            {
                lstSubCat.Items.Clear();
                lstSubCat.Items.Add("$4,999 - 9,999$");
                lstSubCat.Items.Add("$10,000 - 14,999$");
                lstSubCat.Items.Add("more than 15,000$");
            }
        }

        private void lstCars_SelectedIndexChanged(object sender, EventArgs e)
        {
        
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lstSubCat_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboFilter.SelectedIndex == (int)FilterCat.Age)
            {
                if (lstSubCat.SelectedIndex == 0)
                {
                    
                    FillCarListBox_byAge(0, 5);
                }
                else if (lstSubCat.SelectedIndex == 1)
                {
                    FillCarListBox_byAge(5, 10);
                }
                else if (lstSubCat.SelectedIndex == 2)
                {
                    FillCarListBox_byAge(10, 99);
                }
            }
            else if (cboFilter.SelectedIndex == (int)FilterCat.Make) {
                FillCarListBox_byMake(lstSubCat.SelectedItem.ToString()); }
                

            else if (cboFilter.SelectedIndex == (int)FilterCat.Color) {
                FillCarListBox_byColor(lstSubCat.SelectedItem.ToString()); }
           

            else if (cboFilter.SelectedIndex == (int)FilterCat.Price)
            {
                if (lstSubCat.SelectedIndex == 0)
                    FillCarListBox_byPrice(4999, 9999);
                else if (lstSubCat.SelectedIndex == 1)
                    FillCarListBox_byPrice(10000, 14999);
                else
                    FillCarListBox_byPrice(15000, 100000);
            }                                      
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            frmUpload upload = new frmUpload();
            ICar car = upload.GetNewCar();
            if(car != null)
            {
                //cars.Add(car,0);
                //  cars.Add(car, cars.Count()-1);
                cars.Add(car);
                cars.Save();
                FillCarListBox();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int i = lstCars.SelectedIndex;
            if (i != -1)
            {
                ICar car = cars[i];
                string message = "Are you sure you want to delete " +
                    car.Model + "?";

                DialogResult button = MessageBox.Show(message, "Confirm Delete", MessageBoxButtons.YesNo);

                if (button == DialogResult.Yes)
                {
                    cars.Remove(car);
                    cars.Save();
                    FillCarListBox();
                }
            }
        }

        private void frmCarDealership_Load_1(object sender, EventArgs e)
        {

        }        
    }
}

