﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Dealership
{
    class Toyota : Car
    {
        public static string Tag { get; } = "Mileage";
        public string Mileage { set; get; }

        public Toyota(string make, string model, string color, string mileage,DateTime created, decimal price)
         : base(make, model, color, created, price)
        {
            this.Mileage = mileage;
        }

        public Toyota() { }

        public override string GetDisplayText(string sep) =>
            this.Make + sep + this.Model + sep + this.Color + sep + "Mileage: " + this.Mileage + sep +
            this.Age +"Years" + sep + this.Price.ToString("c");

        public override string DisplayTextOnFile(string sep) =>
          this.Make + sep + this.Model + sep + this.Color + sep + "Mileage: " + this.Mileage + sep +
          this.CreatedAt.ToString("MM/dd/yyyy") + sep + this.Price.ToString("c");

        public override string ToString(string sep, Enum filterCat) =>
           base.ToString(sep, filterCat) + sep+ ((Mileage == null) ? "" : Mileage);
      
    }
}
